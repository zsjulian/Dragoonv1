DRAGOON - Wavetable Synthesiser (test build)
============================================

Requirements: Windows 10/11, 64-bit, a VST3 host (FL Studio, Ableton, Reaper, ...)

INSTALL
1. If Windows blocked the download: right-click Dragoon.vst3 > Properties > tick "Unblock" > OK.
2. Copy Dragoon.vst3 into:
       C:\Program Files\Common Files\VST3\
   (Windows will ask for admin permission - accept.)
3. FL Studio: Options > Manage plugins > Find plugins.
   Dragoon shows up under Generators.

TIPS
- The window can be resized by dragging its bottom-right corner.
- LFO SYNC locks the LFO to your project tempo; RETRIG restarts it on every note.

This is a work-in-progress build - sounds and settings may change in later versions.
